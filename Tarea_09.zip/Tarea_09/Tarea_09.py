#encoding: UTF-8
#Autor: Luis Martín Barbosa Galindo A01337485
#Sacar unas fiuras de un archivo

from Myro import pickAFile
from Graphics import *

def hacerVentana(trazos):
    an = int(trazos[2])
    lar = int(trazos[1])
    v = Window(trazos[3],lar,an)
    return v
    
   
def hacerRectangulo(trazos,v):
    a1 = int(trazos[1])
    a2 = int(trazos[2])
    b1 = int(trazos[3])
    b2 = int(trazos[4])
    r = Rectangle((a1,a2),(b1,b2))
    r.fill = Color(color(trazos))
    r.draw(v)
    
def hacerLinea(trazos,v):
    x1 = int(trazos[1])
    y1 = int(trazos[2])
    x2 = int(trazos[3])
    y2 = int(trazos[4])
    l = Line((x1,y1),(x2,y2))
    l.fill = Color(color(trazos))
    l.draw(v)
    
def hacerCirculo(trazos,v):
    x = int(trazos[1])
    y = int(trazos[2])
    rad = int(trazos[3])
    c = Circle((x,y),rad)
    c.fill = Color(color(trazos))
    c.draw(v)
    
    
def color(trazos):
    color = None
    if trazos[0] == "r":
        relleno = trazos[5]
    elif trazos[0] == "l":
        can = len(trazos)
        if can > 4 :
            relleno = "grey"
        else:
            relleno = "black"
    elif trazos[0] == "c":
        relleno = trazos[4]
    return relleno

def main():
    archivo = pickAFile()
    print(archivo)
    imagen = open(archivo,"r")
    linea = imagen.readline()
    for linea in imagen:
        if linea != "#":
            trazos = linea.split()
            if trazos[0] == "v":
                v = hacerVentana(trazos)
            elif trazos[0] == "r":
                hacerRectangulo(trazos,v)
            elif trazos[0] == "l":
                hacerLinea(trazos,v)
            elif trazos[0] == "c":
                hacerCirculo(trazos,v)
    
    imagen.close()
      
main()